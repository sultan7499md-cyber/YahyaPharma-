import { Router, type IRouter } from "express";
import healthRouter from "./health";
import medicinesRouter from "./medicines";
import cartRouter from "./cart";

const router: IRouter = Router();

router.use(healthRouter);
router.use(medicinesRouter);
router.use(cartRouter);

export default router;
