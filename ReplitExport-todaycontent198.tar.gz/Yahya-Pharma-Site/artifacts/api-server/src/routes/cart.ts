import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { cartItemsTable, medicinesTable } from "@workspace/db/schema";
import { eq, and } from "drizzle-orm";

const router: IRouter = Router();

function getSessionId(req: any): string {
  if (!req.cookies?.sessionId) {
    const id = `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    return id;
  }
  return req.cookies.sessionId;
}

function ensureSession(req: any, res: any): string {
  let sessionId = req.cookies?.sessionId;
  if (!sessionId) {
    sessionId = `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    res.cookie("sessionId", sessionId, { maxAge: 7 * 24 * 60 * 60 * 1000, httpOnly: true, sameSite: "lax" });
  }
  return sessionId;
}

async function buildCart(sessionId: string) {
  const items = await db
    .select({
      quantity: cartItemsTable.quantity,
      medicine: medicinesTable,
    })
    .from(cartItemsTable)
    .leftJoin(medicinesTable, eq(cartItemsTable.medicineId, medicinesTable.id))
    .where(eq(cartItemsTable.sessionId, sessionId));

  const cartItems = items
    .filter((item) => item.medicine !== null)
    .map((item) => ({
      medicine: {
        ...item.medicine!,
        price: parseFloat(item.medicine!.price),
        mrp: parseFloat(item.medicine!.mrp),
      },
      quantity: item.quantity,
      totalPrice: parseFloat(item.medicine!.price) * item.quantity,
    }));

  const subtotal = cartItems.reduce((sum, item) => sum + item.totalPrice, 0);

  return {
    items: cartItems,
    subtotal: Math.round(subtotal * 100) / 100,
    total: Math.round(subtotal * 100) / 100,
    itemCount: cartItems.reduce((sum, item) => sum + item.quantity, 0),
  };
}

router.get("/cart", async (req, res) => {
  try {
    const sessionId = getSessionId(req);
    const cart = await buildCart(sessionId);
    res.json(cart);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch cart" });
  }
});

router.post("/cart", async (req, res) => {
  try {
    const sessionId = ensureSession(req, res);
    const { medicineId, quantity = 1 } = req.body;

    if (!medicineId) {
      return res.status(400).json({ error: "medicineId is required" });
    }

    const existing = await db
      .select()
      .from(cartItemsTable)
      .where(and(eq(cartItemsTable.sessionId, sessionId), eq(cartItemsTable.medicineId, medicineId)));

    if (existing.length > 0) {
      await db
        .update(cartItemsTable)
        .set({ quantity: existing[0].quantity + quantity })
        .where(and(eq(cartItemsTable.sessionId, sessionId), eq(cartItemsTable.medicineId, medicineId)));
    } else {
      await db.insert(cartItemsTable).values({ sessionId, medicineId, quantity });
    }

    const cart = await buildCart(sessionId);
    res.json(cart);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to add to cart" });
  }
});

router.delete("/cart/:medicineId", async (req, res) => {
  try {
    const sessionId = getSessionId(req);
    const medicineId = parseInt(req.params.medicineId);

    await db
      .delete(cartItemsTable)
      .where(and(eq(cartItemsTable.sessionId, sessionId), eq(cartItemsTable.medicineId, medicineId)));

    const cart = await buildCart(sessionId);
    res.json(cart);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to remove from cart" });
  }
});

router.patch("/cart/:medicineId", async (req, res) => {
  try {
    const sessionId = getSessionId(req);
    const medicineId = parseInt(req.params.medicineId);
    const { quantity } = req.body;

    if (quantity <= 0) {
      await db
        .delete(cartItemsTable)
        .where(and(eq(cartItemsTable.sessionId, sessionId), eq(cartItemsTable.medicineId, medicineId)));
    } else {
      await db
        .update(cartItemsTable)
        .set({ quantity })
        .where(and(eq(cartItemsTable.sessionId, sessionId), eq(cartItemsTable.medicineId, medicineId)));
    }

    const cart = await buildCart(sessionId);
    res.json(cart);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update cart" });
  }
});

export default router;
