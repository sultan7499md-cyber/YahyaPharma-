import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { medicinesTable } from "@workspace/db/schema";
import { ilike, or, eq, and, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/medicines", async (req, res) => {
  try {
    const { search, category, page = "1", limit = "30" } = req.query as Record<string, string>;
    const pageNum = Math.max(1, parseInt(page));
    const limitNum = Math.min(100, Math.max(1, parseInt(limit)));
    const offset = (pageNum - 1) * limitNum;

    const conditions = [];

    if (search && search.trim()) {
      conditions.push(
        or(
          ilike(medicinesTable.name, `%${search}%`),
          ilike(medicinesTable.genericName, `%${search}%`),
          ilike(medicinesTable.category, `%${search}%`),
          ilike(medicinesTable.manufacturer, `%${search}%`),
          ilike(medicinesTable.description, `%${search}%`)
        )
      );
    }

    if (category && category.trim()) {
      conditions.push(eq(medicinesTable.category, category));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const [medicines, countResult] = await Promise.all([
      db.select().from(medicinesTable).where(whereClause).limit(limitNum).offset(offset),
      db.select({ count: sql<number>`count(*)::int` }).from(medicinesTable).where(whereClause),
    ]);

    const total = countResult[0]?.count ?? 0;
    const totalPages = Math.ceil(total / limitNum);

    res.json({
      medicines: medicines.map((m) => ({
        ...m,
        price: parseFloat(m.price),
        mrp: parseFloat(m.mrp),
      })),
      total,
      page: pageNum,
      limit: limitNum,
      totalPages,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch medicines" });
  }
});

router.get("/medicines/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [medicine] = await db.select().from(medicinesTable).where(eq(medicinesTable.id, id));

    if (!medicine) {
      return res.status(404).json({ error: "Medicine not found" });
    }

    res.json({
      ...medicine,
      price: parseFloat(medicine.price),
      mrp: parseFloat(medicine.mrp),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch medicine" });
  }
});

router.get("/categories", async (_req, res) => {
  try {
    const categories = await db
      .select({
        category: medicinesTable.category,
        count: sql<number>`count(*)::int`,
      })
      .from(medicinesTable)
      .groupBy(medicinesTable.category)
      .orderBy(medicinesTable.category);

    const categoryIcons: Record<string, string> = {
      Diabetes: "🩺",
      "Heart Care": "❤️",
      "Fever & Cold": "🤒",
      "Pain Relief": "💊",
      Vitamins: "🌿",
      Antibiotics: "🦠",
      "Skin Care": "✨",
      "Eye Care": "👁️",
      "Baby Care": "👶",
      "Women's Health": "🌸",
      Ayurvedic: "🍃",
      "Digestive Health": "🫃",
      "Respiratory Care": "🫁",
      "Bone & Joint": "🦴",
      "Mental Health": "🧠",
      Surgical: "🩹",
      Dental: "🦷",
      Homeopathy: "🌱",
      Nutrition: "🥗",
      "Sexual Health": "💙",
    };

    res.json(
      categories.map((c) => ({
        id: c.category.toLowerCase().replace(/\s+/g, "-").replace(/&/g, "and").replace(/'/g, ""),
        name: c.category,
        icon: categoryIcons[c.category] ?? "💊",
        count: c.count,
      }))
    );
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch categories" });
  }
});

export default router;
