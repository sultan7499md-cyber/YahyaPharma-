import React from "react";
import { Link } from "wouter";
import { Layout } from "@/components/layout";
import { MedicineCard } from "@/components/medicine-card";
import { useGetMedicines, useGetCategories } from "@workspace/api-client-react";
import { useSearchParams } from "@/hooks/use-search-params";
import { Skeleton } from "@/components/ui/skeleton";
import { SearchX, LayoutGrid } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const searchParams = useSearchParams();
  const search = searchParams.get("search") || undefined;
  const category = searchParams.get("category") || undefined;
  
  const { data: categories, isLoading: isLoadingCats } = useGetCategories();
  const { data: medicineData, isLoading: isLoadingMeds } = useGetMedicines({
    search,
    category,
    limit: 600
  });

  return (
    <Layout>
      {/* Categories Bar */}
      <div className="bg-white border-b sticky top-[72px] md:top-20 z-40 shadow-sm shadow-black/5">
        <div className="container mx-auto px-4">
          <div className="flex overflow-x-auto hide-scrollbar py-4 gap-3 items-center">
            <Link href="/">
              <button 
                className={`whitespace-nowrap px-5 py-2.5 rounded-full text-sm font-semibold transition-all border ${
                  !category 
                    ? 'bg-primary text-white border-primary shadow-md shadow-primary/20' 
                    : 'bg-secondary/50 text-foreground border-transparent hover:bg-secondary hover:border-border'
                }`}
              >
                All Medicines
              </button>
            </Link>
            
            {isLoadingCats ? (
              Array.from({ length: 8 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-28 rounded-full shrink-0" />
              ))
            ) : (
              categories?.map(cat => (
                <Link key={cat.id} href={`/?category=${encodeURIComponent(cat.name)}`}>
                  <button 
                    className={`whitespace-nowrap px-5 py-2.5 rounded-full text-sm font-semibold transition-all border ${
                      category === cat.name 
                        ? 'bg-primary text-white border-primary shadow-md shadow-primary/20' 
                        : 'bg-secondary/50 text-foreground border-transparent hover:bg-secondary hover:border-border'
                    }`}
                  >
                    {cat.name}
                    <span className="ml-2 opacity-60 text-xs font-normal">({cat.count})</span>
                  </button>
                </Link>
              ))
            )}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="font-display font-extrabold text-2xl md:text-3xl text-foreground flex items-center gap-2">
              <LayoutGrid className="text-primary w-7 h-7" />
              {category ? `${category} Medicines` : search ? `Search Results for "${search}"` : 'Popular Medicines'}
            </h2>
            <p className="text-muted-foreground mt-2 text-sm md:text-base">
              {medicineData?.total || 0} products found
            </p>
          </div>
        </div>

        {isLoadingMeds ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="flex flex-col space-y-3 bg-white p-4 rounded-2xl border border-border/50 shadow-sm">
                <Skeleton className="h-40 w-full rounded-xl" />
                <Skeleton className="h-4 w-3/4 mt-4" />
                <Skeleton className="h-3 w-1/2" />
                <div className="flex justify-between items-center mt-6">
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-9 w-20 rounded-xl" />
                </div>
              </div>
            ))}
          </div>
        ) : medicineData?.medicines && medicineData.medicines.length > 0 ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6"
          >
            {medicineData.medicines.map((medicine) => (
              <MedicineCard key={medicine.id} medicine={medicine} />
            ))}
          </motion.div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center px-4 bg-white rounded-3xl border border-dashed border-border/80 shadow-sm">
            <div className="bg-primary/5 p-6 rounded-full mb-6">
              <SearchX className="w-16 h-16 text-primary/40" />
            </div>
            <h3 className="text-2xl font-display font-bold text-foreground mb-2">No medicines found</h3>
            <p className="text-muted-foreground max-w-md mb-8">
              We couldn't find any products matching your current search or category filters. Try using different keywords.
            </p>
            <Link href="/">
              <button className="bg-primary text-white px-8 py-3 rounded-full font-semibold shadow-lg shadow-primary/20 hover:shadow-primary/40 hover:-translate-y-0.5 transition-all">
                Clear all filters
              </button>
            </Link>
          </div>
        )}
      </div>
    </Layout>
  );
}
