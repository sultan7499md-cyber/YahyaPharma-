import React from "react";
import { Link } from "wouter";
import { Layout } from "@/components/layout";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight, ShieldCheck } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { motion, AnimatePresence } from "framer-motion";

const UPI_ID = "7305575126@superyes";

function generateUpiUrl(amount: number) {
  return `upi://pay?pa=${UPI_ID}&pn=Yahya%20Pharma&am=${amount.toFixed(2)}&cu=INR&tn=Medicine%20Order`;
}

export default function Cart() {
  const { items, itemCount, subtotal, total, removeFromCart, updateQuantity } = useCart();
  const savings = Math.round((subtotal - total) * 100) / 100;

  if (items.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-24 max-w-2xl text-center">
          <div className="bg-white rounded-3xl p-12 border border-border shadow-sm flex flex-col items-center">
            <div className="bg-primary/10 p-6 rounded-full mb-6">
              <ShoppingBag className="w-16 h-16 text-primary" />
            </div>
            <h2 className="text-3xl font-display font-bold text-foreground mb-4">Your cart is empty</h2>
            <p className="text-muted-foreground mb-8 text-lg">
              Looks like you haven't added any medicines yet. Let's find what you need!
            </p>
            <Link href="/">
              <Button size="lg" className="rounded-full px-8 font-bold shadow-lg hover:-translate-y-1 transition-all">
                Browse Medicines
              </Button>
            </Link>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 md:py-12 max-w-6xl">
        <h1 className="text-3xl font-display font-extrabold text-foreground mb-8 flex items-center gap-3">
          <ShoppingBag className="w-8 h-8 text-primary" />
          Your Cart <span className="text-muted-foreground text-xl font-medium">({itemCount} items)</span>
        </h1>

        <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
          
          {/* Cart Items List */}
          <div className="w-full lg:w-2/3">
            <div className="bg-white rounded-3xl border border-border overflow-hidden shadow-sm">
              <AnimatePresence>
                {items.map((item, idx) => (
                  <motion.div 
                    key={item.medicine.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                    className={`p-6 flex flex-col sm:flex-row gap-6 items-start sm:items-center ${
                      idx !== items.length - 1 ? 'border-b border-border' : ''
                    }`}
                  >
                    <Link href={`/medicines/${item.medicine.id}`}>
                      <div className="w-24 h-24 rounded-2xl bg-secondary/50 flex-shrink-0 flex items-center justify-center p-2 cursor-pointer hover:shadow-md transition-shadow">
                        {item.medicine.imageUrl ? (
                          <img src={item.medicine.imageUrl} alt={item.medicine.name} className="w-full h-full object-contain" />
                        ) : (
                          <ShoppingBag className="w-10 h-10 text-muted-foreground" />
                        )}
                      </div>
                    </Link>

                    <div className="flex-1 flex flex-col sm:flex-row justify-between w-full gap-4">
                      <div>
                        <Link href={`/medicines/${item.medicine.id}`}>
                          <h3 className="font-display font-bold text-lg text-foreground hover:text-primary transition-colors cursor-pointer line-clamp-2">
                            {item.medicine.name}
                          </h3>
                        </Link>
                        <p className="text-sm text-muted-foreground mt-1">{item.medicine.category}</p>
                        <p className="font-bold text-primary mt-2">
                          ₹{item.medicine.price.toFixed(2)} <span className="text-xs text-muted-foreground font-normal">/ unit</span>
                        </p>
                      </div>

                      <div className="flex sm:flex-col items-center sm:items-end justify-between gap-4">
                        <div className="flex items-center gap-1 bg-secondary rounded-full p-1 border">
                          <button 
                            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white text-foreground transition-colors disabled:opacity-50"
                            onClick={() => updateQuantity(item.medicine.id, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-8 text-center font-bold text-sm">{item.quantity}</span>
                          <button 
                            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white text-foreground transition-colors"
                            onClick={() => updateQuantity(item.medicine.id, item.quantity + 1)}
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <div className="flex items-center gap-4">
                          <p className="font-display font-bold text-lg text-foreground whitespace-nowrap">
                            ₹{(item.medicine.price * item.quantity).toFixed(2)}
                          </p>
                          <button 
                            className="text-muted-foreground hover:text-destructive p-2 rounded-full hover:bg-destructive/10 transition-colors"
                            onClick={() => removeFromCart(item.medicine.id)}
                            title="Remove item"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
            
            <div className="mt-6 flex items-center gap-3 text-sm text-primary font-medium bg-primary/5 p-4 rounded-xl border border-primary/10">
              <ShieldCheck className="w-5 h-5" />
              All medicines are 100% genuine and sourced from verified distributors.
            </div>
          </div>

          {/* Checkout & UPI Section */}
          <div className="w-full lg:w-1/3">
            <div className="sticky top-28">
              <Card className="rounded-3xl border-border/80 shadow-xl shadow-black/5 overflow-hidden">
                <div className="p-6 bg-white">
                  <h3 className="font-display font-bold text-xl mb-6">Bill Summary</h3>
                  
                  <div className="space-y-4 text-sm">
                    <div className="flex justify-between text-muted-foreground">
                      <span>Item Total (MRP)</span>
                      <span className="line-through">₹{subtotal.toFixed(2)}</span>
                    </div>
                    {savings > 0 && (
                      <div className="flex justify-between text-primary font-medium">
                        <span>Store Discount</span>
                        <span>- ₹{savings.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-muted-foreground">
                      <span>Delivery Fee</span>
                      <span className="text-green-600 font-bold uppercase">Free</span>
                    </div>
                  </div>
                  
                  <Separator className="my-6" />
                  
                  <div className="flex justify-between items-end mb-8">
                    <div>
                      <p className="font-display font-extrabold text-2xl">₹{total.toFixed(2)}</p>
                      <p className="text-xs text-muted-foreground">Total Amount to Pay</p>
                    </div>
                    {savings > 0 && (
                      <div className="bg-green-100 text-green-700 text-xs font-bold px-2 py-1 rounded">
                        You save ₹{savings.toFixed(2)}
                      </div>
                    )}
                  </div>

                  <div className="bg-secondary/50 p-5 rounded-2xl border border-border/50">
                    <h4 className="font-bold text-foreground mb-4 text-center">Pay Securely via UPI</h4>
                    
                    <div className="hidden md:flex flex-col items-center justify-center mb-6 p-4 bg-white rounded-xl shadow-sm border border-border">
                      <QRCodeSVG 
                        value={generateUpiUrl(total)} 
                        size={140}
                        bgColor={"#ffffff"}
                        fgColor={"#000000"}
                        level={"Q"}
                        includeMargin={false}
                      />
                      <p className="text-xs text-center text-muted-foreground mt-3">
                        Scan with any UPI App
                      </p>
                    </div>

                    <div className="grid grid-cols-1 gap-3">
                      <a href={generateUpiUrl(total)} className="w-full">
                        <Button className="w-full h-12 rounded-xl text-white font-bold text-base bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 shadow-md">
                          Pay with GPay
                        </Button>
                      </a>
                      <a href={generateUpiUrl(total)} className="w-full">
                        <Button className="w-full h-12 rounded-xl text-white font-bold text-base bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 shadow-md">
                          Pay with PhonePe
                        </Button>
                      </a>
                      <a href={generateUpiUrl(total)} className="w-full">
                        <Button className="w-full h-12 rounded-xl text-white font-bold text-base bg-gradient-to-r from-sky-500 to-sky-400 hover:from-sky-600 hover:to-sky-500 shadow-md">
                          Pay with Paytm
                        </Button>
                      </a>
                    </div>

                    <div className="mt-5 text-center">
                      <p className="text-xs text-muted-foreground">UPI ID</p>
                      <p className="font-mono font-bold text-foreground mt-1 select-all">{UPI_ID}</p>
                    </div>
                  </div>
                  
                </div>
              </Card>
            </div>
          </div>

        </div>
      </div>
    </Layout>
  );
}
