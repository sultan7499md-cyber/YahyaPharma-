import React, { useState } from "react";
import { useRoute, Link } from "wouter";
import { Layout } from "@/components/layout";
import { useGetMedicineById } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Pill, ShieldCheck, Truck, ShieldAlert, FileText, Factory, Plus, Minus, ShoppingCart, Check } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { motion } from "framer-motion";

export default function MedicineDetail() {
  const [, params] = useRoute("/medicines/:id");
  const id = params?.id ? parseInt(params.id) : 0;
  
  const [quantity, setQuantity] = useState(1);
  const [justAdded, setJustAdded] = useState(false);
  const { data: medicine, isLoading, isError } = useGetMedicineById(id);
  const { addToCart, items, openCart } = useCart();

  const inCart = items.some((i) => i.medicine.id === medicine?.id);

  const handleAddToCart = () => {
    if (medicine) {
      for (let i = 0; i < quantity; i++) {
        addToCart({
          id: medicine.id,
          name: medicine.name,
          genericName: medicine.genericName ?? null,
          category: medicine.category,
          price: medicine.price,
          mrp: medicine.mrp,
          discount: medicine.discount,
          manufacturer: medicine.manufacturer,
          imageUrl: medicine.imageUrl ?? null,
          inStock: medicine.inStock,
        });
      }
      setJustAdded(true);
      setTimeout(() => setJustAdded(false), 2000);
      setQuantity(1);
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8 max-w-6xl">
          <div className="flex flex-col md:flex-row gap-8">
            <Skeleton className="w-full md:w-1/2 aspect-square rounded-3xl" />
            <div className="w-full md:w-1/2 space-y-6">
              <Skeleton className="h-10 w-3/4" />
              <Skeleton className="h-6 w-1/2" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-14 w-40" />
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (isError || !medicine) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h2 className="text-2xl font-bold text-foreground mb-4">Medicine not found</h2>
          <Link href="/">
            <Button>Return to Home</Button>
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="bg-secondary/30 border-b mb-8">
        <div className="container mx-auto px-4 py-4">
          <Link href="/">
            <button className="flex items-center text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to all medicines
            </button>
          </Link>
        </div>
      </div>

      <div className="container mx-auto px-4 pb-20 max-w-6xl">
        <div className="bg-white rounded-3xl p-6 md:p-10 shadow-xl shadow-black/5 border border-border/60">
          <div className="flex flex-col lg:flex-row gap-10 lg:gap-16">
            
            {/* Image Section */}
            <div className="w-full lg:w-5/12 flex-shrink-0">
              <div className="relative aspect-square rounded-3xl bg-secondary/50 flex items-center justify-center p-8 border border-border/50">
                {medicine.discount > 0 && (
                  <Badge className="absolute top-6 left-6 text-sm py-1 px-3 bg-red-500 hover:bg-red-600 text-white font-bold border-none shadow-lg z-10">
                    {medicine.discount}% OFF
                  </Badge>
                )}
                
                {medicine.imageUrl ? (
                  <motion.img 
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.5 }}
                    src={medicine.imageUrl} 
                    alt={medicine.name}
                    className="w-full h-full object-contain drop-shadow-xl"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-primary/30">
                    <Pill className="w-32 h-32 mb-4" />
                    <span className="font-medium text-lg">No Image Available</span>
                  </div>
                )}
              </div>
            </div>

            {/* Details Section */}
            <div className="w-full lg:w-7/12 flex flex-col">
              <div className="mb-6">
                <Badge className="bg-primary/10 text-primary hover:bg-primary/20 border-none mb-4 text-xs font-bold uppercase tracking-widest px-3 py-1">
                  {medicine.category}
                </Badge>
                <h1 className="font-display font-extrabold text-3xl md:text-4xl lg:text-5xl text-foreground leading-tight mb-2">
                  {medicine.name}
                </h1>
                <p className="text-lg text-muted-foreground font-medium flex items-center gap-2">
                  <Factory className="w-5 h-5" /> {medicine.manufacturer}
                </p>
              </div>

              <div className="p-6 bg-secondary/40 rounded-2xl mb-8 border border-border/50">
                <div className="flex items-end gap-4 mb-4">
                  <div>
                    {medicine.discount > 0 && (
                      <p className="text-sm text-muted-foreground line-through mb-1">
                        MRP ₹{medicine.mrp.toFixed(2)}
                      </p>
                    )}
                    <div className="flex items-center gap-3">
                      <p className="font-display font-extrabold text-4xl text-primary">
                        ₹{medicine.price.toFixed(2)}
                      </p>
                      <span className="text-sm text-muted-foreground font-medium mt-2">Inclusive of all taxes</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6 mt-6 pt-6 border-t border-border">
                  <div className="flex items-center gap-3 bg-white rounded-full p-1 shadow-sm border">
                    <button 
                      className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-secondary text-foreground transition-colors disabled:opacity-50"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={quantity <= 1}
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-8 text-center font-bold text-lg">{quantity}</span>
                    <button 
                      className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-secondary text-foreground transition-colors"
                      onClick={() => setQuantity(quantity + 1)}
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <Button 
                    size="lg" 
                    onClick={handleAddToCart}
                    disabled={!medicine.inStock}
                    className={`flex-1 h-14 rounded-full text-base font-bold shadow-xl transition-all hover:-translate-y-1 ${
                      justAdded
                        ? "bg-green-500 hover:bg-green-500 shadow-green-500/20"
                        : "shadow-primary/20 hover:shadow-primary/40"
                    }`}
                  >
                    {justAdded ? (
                      <>
                        <Check className="w-5 h-5 mr-2" />
                        Added to Cart!
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="w-5 h-5 mr-2" />
                        {medicine.inStock ? "Add to Cart" : "Out of Stock"}
                      </>
                    )}
                  </Button>

                  {inCart && (
                    <Button
                      size="lg"
                      variant="outline"
                      onClick={openCart}
                      className="h-14 rounded-full px-5 border-primary text-primary hover:bg-primary hover:text-white transition-all"
                    >
                      View Cart
                    </Button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-10">
                <div className="flex items-center gap-3 p-4 bg-white border rounded-2xl shadow-sm">
                  <div className="bg-primary/10 p-2.5 rounded-full text-primary">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-semibold">100% Genuine</span>
                </div>
                <div className="flex items-center gap-3 p-4 bg-white border rounded-2xl shadow-sm">
                  <div className="bg-primary/10 p-2.5 rounded-full text-primary">
                    <Truck className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-semibold">Fast Delivery</span>
                </div>
              </div>

              <div className="space-y-8">
                {medicine.description && (
                  <div>
                    <h3 className="text-xl font-display font-bold flex items-center gap-2 mb-3">
                      <FileText className="text-primary w-5 h-5" />
                      Description
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {medicine.description}
                    </p>
                  </div>
                )}

                {medicine.dosage && (
                  <div>
                    <h3 className="text-xl font-display font-bold flex items-center gap-2 mb-3">
                      <Pill className="text-primary w-5 h-5" />
                      Dosage
                    </h3>
                    <div className="bg-primary/5 border border-primary/10 p-5 rounded-2xl">
                      <p className="text-foreground font-medium leading-relaxed">
                        {medicine.dosage}
                      </p>
                    </div>
                  </div>
                )}

                {medicine.sideEffects && (
                  <div>
                    <h3 className="text-xl font-display font-bold flex items-center gap-2 mb-3">
                      <ShieldAlert className="text-orange-500 w-5 h-5" />
                      Side Effects
                    </h3>
                    <div className="bg-orange-50 border border-orange-100 p-5 rounded-2xl">
                      <p className="text-orange-900 font-medium leading-relaxed">
                        {medicine.sideEffects}
                      </p>
                    </div>
                  </div>
                )}
              </div>

            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
