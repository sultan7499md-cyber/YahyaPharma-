import React from "react";
import { Link } from "wouter";
import { Pill, Plus, Check } from "lucide-react";
import { Medicine } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/context/CartContext";
import { motion } from "framer-motion";

interface MedicineCardProps {
  medicine: Medicine;
}

export function MedicineCard({ medicine }: MedicineCardProps) {
  const { addToCart, items } = useCart();
  const [justAdded, setJustAdded] = React.useState(false);

  const inCart = items.some((i) => i.medicine.id === medicine.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    addToCart({
      id: medicine.id,
      name: medicine.name,
      genericName: medicine.genericName ?? null,
      category: medicine.category,
      price: medicine.price,
      mrp: medicine.mrp,
      discount: medicine.discount,
      manufacturer: medicine.manufacturer,
      imageUrl: medicine.imageUrl ?? null,
      inStock: medicine.inStock,
    });

    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1500);
  };

  return (
    <Link href={`/medicines/${medicine.id}`}>
      <motion.div 
        whileHover={{ y: -4 }}
        className="h-full"
      >
        <Card className="h-full group cursor-pointer overflow-hidden border-border/60 hover:border-primary/30 hover:shadow-xl hover:shadow-primary/5 transition-all duration-300 flex flex-col bg-white">
          <div className="relative aspect-square p-6 bg-secondary/30 flex items-center justify-center overflow-hidden">
            {medicine.discount > 0 && (
              <Badge className="absolute top-3 left-3 bg-red-500 hover:bg-red-600 text-white font-bold border-none shadow-md z-10">
                {medicine.discount}% OFF
              </Badge>
            )}
            
            {medicine.requiresPrescription && (
              <Badge variant="outline" className="absolute top-3 right-3 bg-white/80 backdrop-blur text-orange-600 border-orange-200 z-10 text-[10px] px-1.5">
                Rx Reqd
              </Badge>
            )}

            {medicine.imageUrl ? (
              <img 
                src={medicine.imageUrl} 
                alt={medicine.name}
                className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-500"
              />
            ) : (
              <div className="w-full h-full rounded-2xl bg-gradient-to-br from-primary/5 to-primary/20 flex flex-col items-center justify-center group-hover:scale-105 transition-transform duration-500 border border-primary/10">
                <Pill className="w-16 h-16 text-primary/40 mb-2" />
                <span className="text-xs font-medium text-primary/40">No Image</span>
              </div>
            )}
          </div>
          
          <div className="p-5 flex flex-col flex-1">
            <div className="mb-2">
              <span className="text-[11px] font-bold text-primary/80 uppercase tracking-wider bg-primary/5 px-2 py-1 rounded-md inline-block mb-2">
                {medicine.category}
              </span>
              <h3 className="font-display font-bold text-foreground leading-tight line-clamp-2 mb-1 group-hover:text-primary transition-colors">
                {medicine.name}
              </h3>
              <p className="text-xs text-muted-foreground line-clamp-1" title={medicine.genericName || medicine.manufacturer}>
                {medicine.genericName || medicine.manufacturer}
              </p>
            </div>
            
            <div className="mt-auto pt-4 flex items-end justify-between">
              <div>
                {medicine.discount > 0 ? (
                  <>
                    <p className="text-xs text-muted-foreground line-through decoration-red-400/50">
                      ₹{medicine.mrp.toFixed(2)}
                    </p>
                    <p className="font-display font-extrabold text-xl text-foreground">
                      ₹{medicine.price.toFixed(2)}
                    </p>
                  </>
                ) : (
                  <p className="font-display font-extrabold text-xl text-foreground">
                    ₹{medicine.price.toFixed(2)}
                  </p>
                )}
              </div>
              
              <motion.div whileTap={{ scale: 0.9 }}>
                <Button 
                  onClick={handleAddToCart}
                  disabled={!medicine.inStock}
                  size="sm"
                  className={`rounded-xl shadow-md transition-all duration-300 ${
                    justAdded
                      ? 'bg-green-500 hover:bg-green-500 shadow-green-500/20'
                      : inCart
                      ? 'bg-primary/80 hover:bg-primary shadow-primary/20'
                      : medicine.inStock 
                      ? 'bg-primary hover:bg-primary/90 shadow-primary/20 hover:shadow-primary/40 hover:-translate-y-0.5' 
                      : 'bg-muted text-muted-foreground'
                  }`}
                >
                  {justAdded ? (
                    <>
                      <Check className="w-4 h-4 mr-1" />
                      Added!
                    </>
                  ) : medicine.inStock ? (
                    <>
                      <Plus className="w-4 h-4 mr-1" />
                      {inCart ? "Add More" : "ADD"}
                    </>
                  ) : (
                    "OUT"
                  )}
                </Button>
              </motion.div>
            </div>
          </div>
        </Card>
      </motion.div>
    </Link>
  );
}
