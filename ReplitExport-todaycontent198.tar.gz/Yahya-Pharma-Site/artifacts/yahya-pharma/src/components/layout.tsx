import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Search, ShoppingCart, Menu, Phone, HeartPulse, 
  Baby, Pill, Activity, ShieldPlus, Eye, Droplets, Smile
} from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/context/CartContext";
import { useDebounce } from "use-debounce";
import { useSearchParams } from "@/hooks/use-search-params";
import { motion, AnimatePresence } from "framer-motion";

const SIDEBAR_CATEGORIES = [
  { name: "Home", icon: HeartPulse, path: "/" },
  { name: "Diabetes", icon: Activity, path: "/?category=Diabetes" },
  { name: "Heart Care", icon: HeartPulse, path: "/?category=Heart+Care" },
  { name: "Fever & Cold", icon: ShieldPlus, path: "/?category=Fever+%26+Cold" },
  { name: "Pain Relief", icon: Pill, path: "/?category=Pain+Relief" },
  { name: "Vitamins", icon: Smile, path: "/?category=Vitamins" },
  { name: "Antibiotics", icon: ShieldPlus, path: "/?category=Antibiotics" },
  { name: "Skin Care", icon: Droplets, path: "/?category=Skin+Care" },
  { name: "Eye Care", icon: Eye, path: "/?category=Eye+Care" },
  { name: "Baby Care", icon: Baby, path: "/?category=Baby+Care" },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const searchParams = useSearchParams();
  const initialSearch = searchParams.get("search") || "";
  
  const [searchValue, setSearchValue] = useState(initialSearch);
  const [debouncedSearch] = useDebounce(searchValue, 400);
  
  const { itemCount, openCart } = useCart();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  React.useEffect(() => {
    const currentCategory = searchParams.get("category");
    const params = new URLSearchParams();
    if (debouncedSearch) params.set("search", debouncedSearch);
    if (currentCategory) params.set("category", currentCategory);
    
    const newSearchString = params.toString();
    const currentSearchString = searchParams.toString();
    
    if (newSearchString !== currentSearchString && (debouncedSearch !== "" || initialSearch !== "")) {
      setLocation(`/?${newSearchString}`);
    }
  }, [debouncedSearch, setLocation, searchParams, initialSearch]);

  return (
    <div className="min-h-screen flex flex-col bg-background pb-20 md:pb-0 relative">
      {/* Top Header */}
      <header className="sticky top-0 z-50 w-full glass border-b">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6 text-primary" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] p-0 border-r-0">
                <SheetTitle className="sr-only">Menu</SheetTitle>
                <div className="p-6 bg-primary/5 flex items-center gap-3 border-b">
                  <img src={`${import.meta.env.BASE_URL}images/logo.png`} alt="Yahya Pharma" className="w-12 h-12 object-contain" />
                  <div>
                    <h2 className="font-display font-bold text-xl text-primary leading-tight">Yahya Pharma</h2>
                    <p className="text-xs text-primary/80 font-medium">அனைவருக்கும் ஆரோக்கியம்</p>
                  </div>
                </div>
                <div className="py-4 flex flex-col gap-1 px-3 overflow-y-auto h-[calc(100vh-100px)]">
                  <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2 px-4">Categories</h3>
                  {SIDEBAR_CATEGORIES.map((cat) => {
                    const Icon = cat.icon;
                    return (
                      <Link 
                        key={cat.name} 
                        href={cat.path}
                        onClick={() => setIsSidebarOpen(false)}
                        className="flex items-center gap-3 px-4 py-3 rounded-xl text-foreground hover:bg-primary/10 hover:text-primary transition-colors font-medium"
                      >
                        <Icon className="w-5 h-5 opacity-70" />
                        {cat.name}
                      </Link>
                    );
                  })}
                </div>
              </SheetContent>
            </Sheet>

            <Link href="/" className="flex items-center gap-3 group cursor-pointer">
              <img 
                src={`${import.meta.env.BASE_URL}images/logo.png`} 
                alt="Yahya Pharma Logo" 
                className="w-10 h-10 md:w-12 md:h-12 object-contain group-hover:scale-105 transition-transform" 
              />
              <div className="hidden sm:block">
                <h1 className="font-display font-extrabold text-2xl text-primary leading-none tracking-tight">
                  Yahya Pharma
                </h1>
                <p className="text-xs text-primary/80 font-medium tracking-wide mt-0.5">
                  அனைவருக்கும் ஆரோக்கியம்
                </p>
              </div>
            </Link>
          </div>

          <div className="flex-1 max-w-2xl mx-auto hidden md:block">
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5 group-focus-within:text-primary transition-colors" />
              <Input 
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                placeholder="Search for medicines, health products..." 
                className="w-full pl-12 pr-4 py-6 rounded-full bg-secondary/50 border-transparent focus-visible:bg-white focus-visible:ring-4 focus-visible:ring-primary/20 focus-visible:border-primary text-base shadow-inner transition-all"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => {
              const searchEl = document.getElementById('mobile-search');
              if (searchEl) searchEl.focus();
            }}>
              <Search className="h-6 w-6 text-primary" />
            </Button>
            
            {/* Cart button — opens drawer */}
            <button onClick={openCart} className="relative cursor-pointer">
              <div className="flex items-center justify-center w-12 h-12 rounded-full border border-primary/20 hover:bg-primary hover:text-white transition-all text-primary bg-white shadow-sm">
                <ShoppingCart className="h-5 w-5" />
              </div>
              <AnimatePresence>
                {itemCount > 0 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0 }}
                    className="absolute -top-1 -right-1"
                  >
                    <Badge className="bg-destructive text-destructive-foreground border-white border-2 rounded-full px-1.5 min-w-[22px] flex justify-center items-center h-[22px] shadow-sm">
                      {itemCount}
                    </Badge>
                  </motion.div>
                )}
              </AnimatePresence>
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        <div className="md:hidden px-4 pb-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input 
              id="mobile-search"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Search medicines..." 
              className="w-full pl-10 rounded-xl bg-secondary/80 border-transparent focus-visible:bg-white focus-visible:ring-2 focus-visible:ring-primary/30"
            />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Floating Call to Order Button */}
      <a 
        href="tel:+917305575126"
        className="fixed bottom-6 right-6 z-50 group"
      >
        <motion.div 
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-primary hover:bg-primary/90 text-white shadow-xl shadow-primary/30 px-5 py-4 rounded-full flex items-center gap-3 border border-white/20 transition-colors"
        >
          <div className="bg-white/20 p-2 rounded-full animate-pulse">
            <Phone className="w-5 h-5 fill-white" />
          </div>
          <span className="font-display font-semibold hidden md:block text-lg">Call to Order</span>
        </motion.div>
      </a>
    </div>
  );
}
