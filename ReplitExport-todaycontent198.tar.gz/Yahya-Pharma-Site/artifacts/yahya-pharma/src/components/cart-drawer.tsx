import React from "react";
import { Link } from "wouter";
import { useCart } from "@/context/CartContext";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  ShoppingBag, Trash2, Plus, Minus, Pill, X, ShieldCheck, ArrowRight
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { QRCodeSVG } from "qrcode.react";

const UPI_ID = "7305575126@superyes";

function generateUpiUrl(amount: number) {
  return `upi://pay?pa=${UPI_ID}&pn=Yahya%20Pharma&am=${amount.toFixed(2)}&cu=INR&tn=Medicine%20Order`;
}

export function CartDrawer() {
  const { items, itemCount, subtotal, total, isOpen, closeCart, removeFromCart, updateQuantity } = useCart();
  const savings = Math.round((subtotal - total) * 100) / 100;

  return (
    <Sheet open={isOpen} onOpenChange={(v) => !v && closeCart()}>
      <SheetContent side="right" className="w-full sm:max-w-md p-0 flex flex-col border-l shadow-2xl">
        <SheetTitle className="sr-only">Shopping Cart</SheetTitle>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b bg-white">
          <div className="flex items-center gap-3">
            <div className="bg-primary/10 p-2 rounded-full">
              <ShoppingBag className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="font-display font-bold text-lg text-foreground leading-tight">Your Cart</h2>
              <p className="text-xs text-muted-foreground">{itemCount} {itemCount === 1 ? "item" : "items"}</p>
            </div>
          </div>
          <button
            onClick={closeCart}
            className="p-2 rounded-full hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full py-16 px-6 text-center">
              <div className="bg-primary/10 p-6 rounded-full mb-5">
                <ShoppingBag className="w-14 h-14 text-primary" />
              </div>
              <h3 className="font-display font-bold text-xl text-foreground mb-2">Cart is empty</h3>
              <p className="text-muted-foreground mb-6 text-sm">Add medicines to get started</p>
              <Button onClick={closeCart} className="rounded-full px-6 font-semibold">
                Browse Medicines
              </Button>
            </div>
          ) : (
            <div className="flex flex-col">
              {/* Items */}
              <AnimatePresence initial={false}>
                {items.map((item) => (
                  <motion.div
                    key={item.medicine.id}
                    layout
                    initial={{ opacity: 0, x: 30 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 30, transition: { duration: 0.18 } }}
                    className="flex items-center gap-3 px-5 py-4 border-b border-border/60 last:border-0 bg-white"
                  >
                    {/* Image */}
                    <Link href={`/medicines/${item.medicine.id}`} onClick={closeCart}>
                      <div className="w-16 h-16 rounded-xl bg-secondary/40 flex-shrink-0 flex items-center justify-center cursor-pointer">
                        {item.medicine.imageUrl ? (
                          <img src={item.medicine.imageUrl} alt={item.medicine.name} className="w-full h-full object-contain rounded-xl" />
                        ) : (
                          <Pill className="w-8 h-8 text-primary/30" />
                        )}
                      </div>
                    </Link>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <Link href={`/medicines/${item.medicine.id}`} onClick={closeCart}>
                        <h4 className="font-semibold text-sm text-foreground leading-tight line-clamp-2 cursor-pointer hover:text-primary transition-colors">
                          {item.medicine.name}
                        </h4>
                      </Link>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="font-bold text-primary text-sm">₹{item.medicine.price.toFixed(2)}</span>
                        {item.medicine.discount > 0 && (
                          <span className="text-xs text-muted-foreground line-through">₹{item.medicine.mrp.toFixed(2)}</span>
                        )}
                      </div>

                      {/* Qty controls */}
                      <div className="flex items-center gap-2 mt-2">
                        <div className="flex items-center gap-1 bg-secondary rounded-full px-1 py-0.5 border">
                          <button
                            onClick={() => updateQuantity(item.medicine.id, item.quantity - 1)}
                            className="w-6 h-6 flex items-center justify-center rounded-full hover:bg-white text-foreground transition-colors"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-6 text-center font-bold text-sm">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.medicine.id, item.quantity + 1)}
                            className="w-6 h-6 flex items-center justify-center rounded-full hover:bg-white text-foreground transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <span className="text-xs text-muted-foreground font-medium">
                          = ₹{(item.medicine.price * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    </div>

                    {/* Remove */}
                    <button
                      onClick={() => removeFromCart(item.medicine.id)}
                      className="p-1.5 rounded-full text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors flex-shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Trust badge */}
              <div className="flex items-center gap-2 text-xs text-primary font-medium bg-primary/5 px-5 py-3 border-b">
                <ShieldCheck className="w-4 h-4 flex-shrink-0" />
                100% genuine medicines from verified distributors
              </div>
            </div>
          )}
        </div>

        {/* Footer (only when items present) */}
        {items.length > 0 && (
          <div className="border-t bg-white">
            {/* Bill summary */}
            <div className="px-5 py-4 space-y-2 text-sm">
              <div className="flex justify-between text-muted-foreground">
                <span>Item Total (MRP)</span>
                <span className="line-through">₹{subtotal.toFixed(2)}</span>
              </div>
              {savings > 0 && (
                <div className="flex justify-between text-green-600 font-medium">
                  <span>You Save</span>
                  <span>- ₹{savings.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-muted-foreground">
                <span>Delivery</span>
                <span className="text-green-600 font-bold text-xs uppercase">Free</span>
              </div>
              <Separator className="my-1" />
              <div className="flex justify-between font-display font-extrabold text-base">
                <span>Total</span>
                <span>₹{total.toFixed(2)}</span>
              </div>
            </div>

            {/* UPI Payment */}
            <div className="px-5 pb-5 space-y-3">
              {/* QR Code (visible on wider drawers) */}
              <div className="hidden sm:flex flex-col items-center bg-secondary/40 rounded-2xl p-4 border border-border/60">
                <p className="text-xs font-bold text-foreground mb-3 text-center">Scan to Pay via UPI</p>
                <QRCodeSVG
                  value={generateUpiUrl(total)}
                  size={110}
                  bgColor="#ffffff"
                  fgColor="#000000"
                  level="Q"
                  includeMargin={false}
                />
                <p className="font-mono text-xs text-muted-foreground mt-2">{UPI_ID}</p>
              </div>

              {/* Payment buttons */}
              <div className="grid grid-cols-3 gap-2">
                <a href={generateUpiUrl(total)} className="col-span-1">
                  <Button className="w-full text-xs font-bold bg-gradient-to-br from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white rounded-xl h-10 shadow-md">
                    GPay
                  </Button>
                </a>
                <a href={generateUpiUrl(total)} className="col-span-1">
                  <Button className="w-full text-xs font-bold bg-gradient-to-br from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 text-white rounded-xl h-10 shadow-md">
                    PhonePe
                  </Button>
                </a>
                <a href={generateUpiUrl(total)} className="col-span-1">
                  <Button className="w-full text-xs font-bold bg-gradient-to-br from-sky-500 to-sky-400 hover:from-sky-600 hover:to-sky-500 text-white rounded-xl h-10 shadow-md">
                    Paytm
                  </Button>
                </a>
              </div>

              <Link href="/cart" onClick={closeCart}>
                <Button className="w-full rounded-xl h-12 font-bold text-base shadow-lg shadow-primary/20 flex items-center gap-2">
                  View Full Cart
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
