import { db } from "@workspace/db";
import { medicinesTable } from "@workspace/db/schema";

const moreMedicines: Array<{
  name: string;
  genericName?: string;
  category: string;
  price: number;
  mrp: number;
  discount: number;
  manufacturer: string;
  description: string;
  dosage?: string;
  sideEffects?: string;
  requiresPrescription?: boolean;
  inStock?: boolean;
}> = [
  // More Diabetes (10)
  { name: "Empagliflozin 10mg", genericName: "Empagliflozin", category: "Diabetes", price: 225, mrp: 295, discount: 24, manufacturer: "Boehringer Ingelheim", description: "SGLT2 inhibitor for type 2 diabetes and heart protection", dosage: "1 tablet once daily in the morning", sideEffects: "Genital infections, increased urination", requiresPrescription: true },
  { name: "Dapagliflozin 10mg", genericName: "Dapagliflozin", category: "Diabetes", price: 215, mrp: 280, discount: 23, manufacturer: "AstraZeneca", description: "SGLT2 inhibitor for type 2 diabetes", dosage: "1 tablet once daily", sideEffects: "Urinary tract infections, genital infections", requiresPrescription: true },
  { name: "Canagliflozin 100mg", genericName: "Canagliflozin", category: "Diabetes", price: 235, mrp: 305, discount: 23, manufacturer: "Janssen", description: "SGLT2 inhibitor lowering blood sugar and body weight", dosage: "1 tablet once daily before first meal", sideEffects: "UTI, genital mycotic infections", requiresPrescription: true },
  { name: "Linagliptin 5mg", genericName: "Linagliptin", category: "Diabetes", price: 140, mrp: 185, discount: 24, manufacturer: "Boehringer Ingelheim", description: "DPP-4 inhibitor for type 2 diabetes", dosage: "1 tablet once daily", sideEffects: "Nasopharyngitis, hypoglycemia when combined", requiresPrescription: true },
  { name: "Acarbose 50mg", genericName: "Acarbose", category: "Diabetes", price: 68, mrp: 88, discount: 23, manufacturer: "Bayer", description: "Alpha-glucosidase inhibitor, delays glucose absorption", dosage: "1 tablet thrice daily with meals", sideEffects: "Flatulence, diarrhea, abdominal discomfort", requiresPrescription: true },
  { name: "Repaglinide 0.5mg", genericName: "Repaglinide", category: "Diabetes", price: 52, mrp: 68, discount: 24, manufacturer: "Novo Nordisk", description: "Short-acting insulin secretagogue", dosage: "1 tablet 15 minutes before each meal", sideEffects: "Hypoglycemia, nausea", requiresPrescription: true },
  { name: "Glucobay 25mg", genericName: "Acarbose", category: "Diabetes", price: 45, mrp: 58, discount: 22, manufacturer: "Bayer", description: "Controls postprandial blood glucose", dosage: "Start with 25mg thrice daily, increase gradually", sideEffects: "Gas, abdominal pain", requiresPrescription: true },
  { name: "Mixtard 30/70 Insulin", genericName: "Biphasic Isophane Insulin", category: "Diabetes", price: 180, mrp: 235, discount: 23, manufacturer: "Novo Nordisk", description: "Premixed insulin for type 1 and 2 diabetes", dosage: "As directed by physician, inject subcutaneously", sideEffects: "Hypoglycemia, injection site reactions", requiresPrescription: true },
  { name: "Trulicity 0.75mg", genericName: "Dulaglutide", category: "Diabetes", price: 850, mrp: 1100, discount: 23, manufacturer: "Eli Lilly", description: "GLP-1 receptor agonist weekly injection for type 2 diabetes", dosage: "0.75mg once weekly by subcutaneous injection", sideEffects: "Nausea, diarrhea, vomiting", requiresPrescription: true },
  { name: "Glucophage XR 500mg", genericName: "Metformin Extended Release", category: "Diabetes", price: 55, mrp: 72, discount: 24, manufacturer: "Merck", description: "Extended release metformin for better tolerance", dosage: "1-2 tablets once daily with evening meal", sideEffects: "Less GI side effects than regular metformin", requiresPrescription: true },

  // More Heart Care (10)
  { name: "Sacubitril/Valsartan 50mg", genericName: "Sacubitril + Valsartan", category: "Heart Care", price: 185, mrp: 245, discount: 24, manufacturer: "Novartis", description: "Neprilysin inhibitor + ARB for heart failure", dosage: "1 tablet twice daily", sideEffects: "Hypotension, hyperkalemia, renal impairment", requiresPrescription: true },
  { name: "Ivabradine 5mg", genericName: "Ivabradine", category: "Heart Care", price: 145, mrp: 192, discount: 25, manufacturer: "Servier", description: "Heart rate lowering agent for stable angina and heart failure", dosage: "1 tablet twice daily with meals", sideEffects: "Bradycardia, visual disturbances", requiresPrescription: true },
  { name: "Digoxin 0.25mg", genericName: "Digoxin", category: "Heart Care", price: 28, mrp: 36, discount: 22, manufacturer: "Sun Pharma", description: "Cardiac glycoside for heart failure and arrhythmias", dosage: "As prescribed, usually 0.125-0.25mg once daily", sideEffects: "Nausea, bradycardia, visual changes", requiresPrescription: true },
  { name: "Spironolactone 25mg", genericName: "Spironolactone", category: "Heart Care", price: 35, mrp: 46, discount: 24, manufacturer: "Pfizer", description: "Aldosterone antagonist diuretic for heart failure", dosage: "1-2 tablets once daily", sideEffects: "Hyperkalemia, gynecomastia, menstrual irregularities", requiresPrescription: true },
  { name: "Diltiazem 60mg", genericName: "Diltiazem HCl", category: "Heart Care", price: 48, mrp: 62, discount: 23, manufacturer: "Torrent", description: "Calcium channel blocker for angina and arrhythmias", dosage: "1 tablet 3 times daily before meals", sideEffects: "Bradycardia, edema, dizziness", requiresPrescription: true },
  { name: "Verapamil 80mg", genericName: "Verapamil", category: "Heart Care", price: 42, mrp: 55, discount: 24, manufacturer: "Abbott", description: "Calcium channel blocker for angina, hypertension, SVT", dosage: "1 tablet 3 times daily", sideEffects: "Constipation, bradycardia, hypotension", requiresPrescription: true },
  { name: "Torsemide 10mg", genericName: "Torsemide", category: "Heart Care", price: 38, mrp: 50, discount: 24, manufacturer: "Cipla", description: "Loop diuretic for edema associated with heart failure", dosage: "1 tablet once daily in the morning", sideEffects: "Electrolyte imbalances, increased urination", requiresPrescription: true },
  { name: "Hydralazine 25mg", genericName: "Hydralazine HCl", category: "Heart Care", price: 30, mrp: 40, discount: 25, manufacturer: "Sun Pharma", description: "Vasodilator for hypertension and heart failure", dosage: "1 tablet 2-4 times daily", sideEffects: "Headache, tachycardia, lupus-like syndrome", requiresPrescription: true },
  { name: "Eplerenone 25mg", genericName: "Eplerenone", category: "Heart Care", price: 125, mrp: 165, discount: 24, manufacturer: "Pfizer", description: "Selective aldosterone blocker for heart failure post-MI", dosage: "1 tablet once daily, may increase to 50mg", sideEffects: "Hyperkalemia, increased creatinine", requiresPrescription: true },
  { name: "Ranolazine 500mg", genericName: "Ranolazine", category: "Heart Care", price: 155, mrp: 205, discount: 24, manufacturer: "Gilead", description: "Anti-anginal agent for chronic stable angina", dosage: "1 tablet twice daily (extended release)", sideEffects: "Dizziness, nausea, constipation", requiresPrescription: true },

  // More Pain Relief (10)
  { name: "Celecoxib 200mg", genericName: "Celecoxib", category: "Pain Relief", price: 92, mrp: 120, discount: 23, manufacturer: "Pfizer", description: "COX-2 selective NSAID for arthritis and acute pain", dosage: "1-2 capsules daily", sideEffects: "GI discomfort, increased cardiovascular risk", requiresPrescription: true },
  { name: "Etoricoxib 90mg", genericName: "Etoricoxib", category: "Pain Relief", price: 88, mrp: 115, discount: 23, manufacturer: "MSD", description: "Selective COX-2 inhibitor for arthritis pain", dosage: "1 tablet once daily", sideEffects: "Edema, hypertension, GI discomfort", requiresPrescription: true },
  { name: "Tramadol 50mg", genericName: "Tramadol HCl", category: "Pain Relief", price: 35, mrp: 46, discount: 24, manufacturer: "Zydus", description: "Opioid analgesic for moderate to severe pain", dosage: "1-2 tablets every 4-6 hours as needed", sideEffects: "Nausea, dizziness, constipation, dependence risk", requiresPrescription: true },
  { name: "Pregabalin 75mg", genericName: "Pregabalin", category: "Pain Relief", price: 75, mrp: 98, discount: 23, manufacturer: "Pfizer", description: "For neuropathic pain, fibromyalgia, and anxiety", dosage: "1 capsule twice daily", sideEffects: "Dizziness, somnolence, weight gain", requiresPrescription: true },
  { name: "Gabapentin 300mg", genericName: "Gabapentin", category: "Pain Relief", price: 55, mrp: 72, discount: 24, manufacturer: "Sun Pharma", description: "Anticonvulsant for neuropathic pain", dosage: "1 capsule 3 times daily", sideEffects: "Dizziness, fatigue, peripheral edema", requiresPrescription: true },
  { name: "Ketorolac 10mg", genericName: "Ketorolac Tromethamine", category: "Pain Relief", price: 28, mrp: 36, discount: 22, manufacturer: "Sun Pharma", description: "Potent short-term NSAID for acute pain", dosage: "1 tablet every 4-6 hours, max 5 days", sideEffects: "GI bleeding risk, renal effects", requiresPrescription: true },
  { name: "Mefenamic Acid 500mg", genericName: "Mefenamic Acid", category: "Pain Relief", price: 22, mrp: 30, discount: 27, manufacturer: "Lupin", description: "NSAID for pain, especially menstrual pain", dosage: "1 tablet 3 times daily with food", sideEffects: "GI upset, dizziness, headache", requiresPrescription: false },
  { name: "Naproxen 250mg", genericName: "Naproxen", category: "Pain Relief", price: 32, mrp: 42, discount: 24, manufacturer: "Cipla", description: "Long-acting NSAID for pain and inflammation", dosage: "1 tablet twice daily with food", sideEffects: "GI irritation, cardiovascular risk", requiresPrescription: false },
  { name: "Piroxicam 20mg", genericName: "Piroxicam", category: "Pain Relief", price: 38, mrp: 50, discount: 24, manufacturer: "Pfizer", description: "Long-acting NSAID for arthritis and musculoskeletal pain", dosage: "1 capsule once daily with food", sideEffects: "GI ulcers, renal effects", requiresPrescription: true },
  { name: "Tapentadol 50mg", genericName: "Tapentadol", category: "Pain Relief", price: 95, mrp: 125, discount: 24, manufacturer: "Grunenthal", description: "Dual-action opioid analgesic for moderate severe pain", dosage: "1 tablet every 4-6 hours as needed", sideEffects: "Nausea, dizziness, somnolence", requiresPrescription: true },

  // More Vitamins & Supplements (10)
  { name: "Vitamin B12 1500mcg", genericName: "Methylcobalamin", category: "Vitamins", price: 78, mrp: 100, discount: 22, manufacturer: "Sun Pharma", description: "High-dose B12 for nerve health and anemia", dosage: "1 tablet daily or as directed", sideEffects: "Rarely allergic reactions", requiresPrescription: false },
  { name: "Iron + Folic Acid", genericName: "Ferrous Sulphate + Folic Acid", category: "Vitamins", price: 32, mrp: 42, discount: 24, manufacturer: "Macleods", description: "Iron and folic acid supplement for anemia", dosage: "1 tablet daily with water", sideEffects: "Constipation, dark stools, nausea", requiresPrescription: false },
  { name: "Calcium Citrate 500mg", genericName: "Calcium Citrate", category: "Vitamins", price: 52, mrp: 68, discount: 24, manufacturer: "Pfizer", description: "Highly absorbable calcium for bone health", dosage: "1 tablet twice daily with food", sideEffects: "Constipation, gas", requiresPrescription: false },
  { name: "Magnesium Glycinate 400mg", genericName: "Magnesium Glycinate", category: "Vitamins", price: 95, mrp: 125, discount: 24, manufacturer: "Himalaya", description: "Highly bioavailable magnesium for sleep and muscle health", dosage: "1-2 capsules daily at bedtime", sideEffects: "Loose stools at high doses", requiresPrescription: false },
  { name: "Zinc 50mg", genericName: "Zinc Sulphate", category: "Vitamins", price: 35, mrp: 46, discount: 24, manufacturer: "Abbott", description: "Essential mineral for immunity and wound healing", dosage: "1 tablet daily with food", sideEffects: "Nausea if taken on empty stomach", requiresPrescription: false },
  { name: "Vitamin K2 100mcg", genericName: "Menaquinone-7", category: "Vitamins", price: 125, mrp: 165, discount: 24, manufacturer: "Sun Pharma", description: "Directs calcium to bones, supports cardiovascular health", dosage: "1 capsule daily with fat-containing meal", sideEffects: "Rarely GI discomfort", requiresPrescription: false },
  { name: "Biotin 10000mcg", genericName: "Biotin (Vitamin B7)", category: "Vitamins", price: 85, mrp: 112, discount: 24, manufacturer: "NOW Foods", description: "High-dose biotin for hair, skin, and nail health", dosage: "1 tablet daily", sideEffects: "May affect thyroid test results", requiresPrescription: false },
  { name: "Vitamin E 400 IU", genericName: "Alpha-tocopherol", category: "Vitamins", price: 48, mrp: 62, discount: 23, manufacturer: "Merck", description: "Antioxidant vitamin for skin health and immunity", dosage: "1 capsule daily with food", sideEffects: "High doses may increase bleeding risk", requiresPrescription: false },
  { name: "CoQ10 100mg", genericName: "Coenzyme Q10", category: "Vitamins", price: 165, mrp: 215, discount: 23, manufacturer: "Solgar", description: "Essential enzyme for cellular energy production and heart health", dosage: "1 capsule daily with food", sideEffects: "Mild GI discomfort rarely", requiresPrescription: false },
  { name: "Omega-3 with Vitamin D3", genericName: "Fish Oil + Cholecalciferol", category: "Vitamins", price: 145, mrp: 190, discount: 24, manufacturer: "Dr. Reddy's", description: "Combined heart and bone health supplement", dosage: "1 softgel daily with meal", sideEffects: "Fish burps, GI discomfort", requiresPrescription: false },

  // More Skin Care (10)
  { name: "Tretinoin 0.05% Cream", genericName: "Tretinoin", category: "Skin Care", price: 135, mrp: 178, discount: 24, manufacturer: "Janssen", description: "Retinoid for acne, fine lines, and skin renewal", dosage: "Apply thin layer at night to affected area", sideEffects: "Dryness, peeling, sun sensitivity", requiresPrescription: true },
  { name: "Adapalene 0.1% Gel", genericName: "Adapalene", category: "Skin Care", price: 98, mrp: 128, discount: 23, manufacturer: "Galderma", description: "Retinoid gel for acne treatment", dosage: "Apply once daily at night", sideEffects: "Dryness, redness, peeling", requiresPrescription: false },
  { name: "Azelaic Acid 15% Gel", genericName: "Azelaic Acid", category: "Skin Care", price: 145, mrp: 190, discount: 24, manufacturer: "Bayer", description: "For acne, rosacea, and hyperpigmentation", dosage: "Apply twice daily to clean skin", sideEffects: "Mild burning, tingling, dryness", requiresPrescription: false },
  { name: "Clindamycin 1% Gel", genericName: "Clindamycin Phosphate", category: "Skin Care", price: 78, mrp: 102, discount: 24, manufacturer: "Stiefel", description: "Topical antibiotic for acne", dosage: "Apply to affected area twice daily", sideEffects: "Dryness, oiliness, skin peeling", requiresPrescription: true },
  { name: "Tacrolimus 0.03% Ointment", genericName: "Tacrolimus", category: "Skin Care", price: 285, mrp: 375, discount: 24, manufacturer: "Astellas", description: "Calcineurin inhibitor for atopic dermatitis/eczema", dosage: "Apply thin layer twice daily", sideEffects: "Burning, stinging, itching", requiresPrescription: true },
  { name: "Clobetasol 0.05% Cream", genericName: "Clobetasol Propionate", category: "Skin Care", price: 48, mrp: 62, discount: 23, manufacturer: "GSK", description: "Potent corticosteroid for severe skin inflammation", dosage: "Apply sparingly twice daily, max 2 weeks", sideEffects: "Skin thinning with prolonged use", requiresPrescription: true },
  { name: "Terbinafine 1% Cream", genericName: "Terbinafine HCl", category: "Skin Care", price: 65, mrp: 85, discount: 24, manufacturer: "Novartis", description: "Antifungal cream for ringworm and athlete's foot", dosage: "Apply once or twice daily for 1-2 weeks", sideEffects: "Local irritation, redness", requiresPrescription: false },
  { name: "Mupirocin 2% Ointment", genericName: "Mupirocin", category: "Skin Care", price: 55, mrp: 72, discount: 24, manufacturer: "GSK", description: "Topical antibiotic for bacterial skin infections", dosage: "Apply 3 times daily for 5-10 days", sideEffects: "Burning, stinging, local irritation", requiresPrescription: true },
  { name: "Calamine Lotion 100ml", genericName: "Calamine + Zinc Oxide", category: "Skin Care", price: 42, mrp: 55, discount: 24, manufacturer: "Elder", description: "Soothing lotion for itching and skin irritation", dosage: "Apply to affected area as needed", sideEffects: "Rarely skin dryness", requiresPrescription: false },
  { name: "Kojic Acid 2% Cream", genericName: "Kojic Acid", category: "Skin Care", price: 185, mrp: 242, discount: 24, manufacturer: "Dermatica", description: "Skin lightening cream for dark spots and hyperpigmentation", dosage: "Apply once daily at night", sideEffects: "Contact dermatitis, sun sensitivity", requiresPrescription: false },

  // More Baby Care (5)
  { name: "Vitamin D3 400IU Drops", genericName: "Cholecalciferol", category: "Baby Care", price: 85, mrp: 110, discount: 23, manufacturer: "Abbott", description: "Vitamin D drops for infants to prevent deficiency", dosage: "1ml (400IU) daily", sideEffects: "Rare at recommended doses", requiresPrescription: false },
  { name: "Probiotics Infant Drops", genericName: "Lactobacillus reuteri", category: "Baby Care", price: 320, mrp: 420, discount: 24, manufacturer: "Biogaia", description: "Probiotic drops for infant colic and digestive health", dosage: "5 drops daily", sideEffects: "Mild gas initially", requiresPrescription: false },
  { name: "Zinc Sulphate Syrup 50ml", genericName: "Zinc Sulphate", category: "Baby Care", price: 58, mrp: 76, discount: 24, manufacturer: "Ranbaxy", description: "Zinc syrup for diarrhea management in children", dosage: "10-20mg daily for 10-14 days", sideEffects: "Nausea at higher doses", requiresPrescription: false },
  { name: "Ferric Polymaltose Drops", genericName: "Ferric Polymaltose", category: "Baby Care", price: 95, mrp: 125, discount: 24, manufacturer: "Vifor Pharma", description: "Iron drops for iron deficiency anemia in infants", dosage: "As directed by pediatrician", sideEffects: "Dark stools, GI discomfort", requiresPrescription: false },
  { name: "Oral Rehydration Sachets", genericName: "ORS", category: "Baby Care", price: 28, mrp: 36, discount: 22, manufacturer: "Sun Pharma", description: "Electrolyte replenishment for dehydration during diarrhea", dosage: "Dissolve 1 sachet in 200ml clean water", sideEffects: "None when used as directed", requiresPrescription: false },

  // More Women's Health (5)
  { name: "Progesterone 200mg Capsule", genericName: "Micronized Progesterone", category: "Women's Health", price: 115, mrp: 150, discount: 23, manufacturer: "Sun Pharma", description: "Natural progesterone for hormonal support and pregnancy", dosage: "1-2 capsules at bedtime as directed", sideEffects: "Drowsiness, dizziness, breast tenderness", requiresPrescription: true },
  { name: "Letrozole 2.5mg", genericName: "Letrozole", category: "Women's Health", price: 85, mrp: 110, discount: 23, manufacturer: "Novartis", description: "Aromatase inhibitor for infertility treatment and breast cancer", dosage: "1 tablet once daily days 3-7 of cycle", sideEffects: "Hot flashes, fatigue, bone pain", requiresPrescription: true },
  { name: "Tranexamic Acid 500mg", genericName: "Tranexamic Acid", category: "Women's Health", price: 42, mrp: 55, discount: 24, manufacturer: "Pfizer", description: "For heavy menstrual bleeding", dosage: "1-2 tablets 3 times daily during menstruation", sideEffects: "Nausea, diarrhea", requiresPrescription: true },
  { name: "Dydrogesterone 10mg", genericName: "Dydrogesterone", category: "Women's Health", price: 95, mrp: 125, discount: 24, manufacturer: "Abbott", description: "Progestogen for menstrual disorders and infertility support", dosage: "1 tablet twice daily as directed", sideEffects: "Breakthrough bleeding, breast tenderness", requiresPrescription: true },
  { name: "Evening Primrose Oil 1000mg", genericName: "Gamma-Linolenic Acid", category: "Women's Health", price: 165, mrp: 215, discount: 23, manufacturer: "Blackmores", description: "Natural supplement for PMS, menopausal symptoms, and skin health", dosage: "1-2 capsules daily with food", sideEffects: "Nausea, headache at high doses", requiresPrescription: false },

  // More Ayurvedic (5)
  { name: "Brahmi Tablets", genericName: "Bacopa monnieri Extract", category: "Ayurvedic", price: 95, mrp: 125, discount: 24, manufacturer: "Himalaya", description: "Improves memory, concentration and cognitive function", dosage: "2 tablets twice daily after meals", sideEffects: "Nausea, stomach cramps at high doses", requiresPrescription: false },
  { name: "Guduchi Ghana Vati", genericName: "Tinospora cordifolia", category: "Ayurvedic", price: 72, mrp: 94, discount: 23, manufacturer: "Dabur", description: "Immunity booster and anti-inflammatory herb", dosage: "2 tablets twice daily with warm water", sideEffects: "Rare, may lower blood sugar", requiresPrescription: false },
  { name: "Arjuna Capsules", genericName: "Terminalia arjuna Extract", category: "Ayurvedic", price: 85, mrp: 112, discount: 24, manufacturer: "Himalaya", description: "Heart tonic for cardiovascular support", dosage: "1 capsule twice daily", sideEffects: "Rare, mild GI discomfort", requiresPrescription: false },
  { name: "Trikatu Churna", genericName: "Ginger + Long Pepper + Black Pepper", category: "Ayurvedic", price: 45, mrp: 58, discount: 22, manufacturer: "Patanjali", description: "Digestive and respiratory herbal powder", dosage: "1/4 teaspoon twice daily with honey", sideEffects: "Heartburn at high doses", requiresPrescription: false },
  { name: "Shatavari Kalpa", genericName: "Asparagus racemosus", category: "Ayurvedic", price: 115, mrp: 150, discount: 23, manufacturer: "Zandu", description: "Female reproductive tonic and lactation enhancer", dosage: "1-2 tablespoons with warm milk daily", sideEffects: "Rare allergic reactions", requiresPrescription: false },

  // More Mental Health (5)
  { name: "Quetiapine 25mg", genericName: "Quetiapine Fumarate", category: "Mental Health", price: 65, mrp: 85, discount: 24, manufacturer: "AstraZeneca", description: "Atypical antipsychotic for schizophrenia, bipolar, depression", dosage: "25-50mg at bedtime initially", sideEffects: "Drowsiness, weight gain, dry mouth", requiresPrescription: true },
  { name: "Aripiprazole 10mg", genericName: "Aripiprazole", category: "Mental Health", price: 145, mrp: 190, discount: 24, manufacturer: "Otsuka", description: "Atypical antipsychotic with partial dopamine agonism", dosage: "1 tablet once daily", sideEffects: "Akathisia, nausea, insomnia", requiresPrescription: true },
  { name: "Lamotrigine 50mg", genericName: "Lamotrigine", category: "Mental Health", price: 85, mrp: 112, discount: 24, manufacturer: "GSK", description: "Mood stabilizer for bipolar disorder and epilepsy", dosage: "Start at 25mg, titrate slowly as directed", sideEffects: "Rash (stop immediately), dizziness", requiresPrescription: true },
  { name: "Bupropion 150mg", genericName: "Bupropion HCl", category: "Mental Health", price: 125, mrp: 165, discount: 24, manufacturer: "GSK", description: "Antidepressant and smoking cessation aid", dosage: "1 tablet once daily initially, may increase", sideEffects: "Insomnia, dry mouth, seizure risk", requiresPrescription: true },
  { name: "Melatonin 5mg", genericName: "Melatonin", category: "Mental Health", price: 58, mrp: 76, discount: 24, manufacturer: "Mankind", description: "Hormone supplement for insomnia and jet lag", dosage: "1 tablet 30-60 minutes before bedtime", sideEffects: "Drowsiness, headache", requiresPrescription: false },

  // More Digestive (5)
  { name: "Rifaximin 550mg", genericName: "Rifaximin", category: "Digestive Health", price: 185, mrp: 242, discount: 24, manufacturer: "Cipla", description: "Gut-specific antibiotic for traveler's diarrhea and IBS", dosage: "1 tablet 3 times daily for 3 days", sideEffects: "Nausea, flatulence, headache", requiresPrescription: true },
  { name: "Mesalazine 400mg", genericName: "Mesalazine (5-ASA)", category: "Digestive Health", price: 125, mrp: 165, discount: 24, manufacturer: "Ferring", description: "Anti-inflammatory for ulcerative colitis and Crohn's disease", dosage: "2-3 tablets 3 times daily", sideEffects: "Nausea, headache, abdominal pain", requiresPrescription: true },
  { name: "Buscopan 10mg", genericName: "Hyoscine Butylbromide", category: "Digestive Health", price: 42, mrp: 55, discount: 24, manufacturer: "Sanofi", description: "Antispasmodic for abdominal cramps and IBS", dosage: "1-2 tablets 3-4 times daily", sideEffects: "Dry mouth, blurred vision, urinary retention", requiresPrescription: false },
  { name: "Simethicone 40mg", genericName: "Simethicone", category: "Digestive Health", price: 28, mrp: 36, discount: 22, manufacturer: "Pfizer", description: "Anti-gas agent for bloating and flatulence", dosage: "1-2 tablets after meals and at bedtime", sideEffects: "None significant", requiresPrescription: false },
  { name: "Lactulose Solution 200ml", genericName: "Lactulose", category: "Digestive Health", price: 65, mrp: 85, discount: 24, manufacturer: "Duphar", description: "Osmotic laxative for constipation and hepatic encephalopathy", dosage: "15-45ml daily, adjust to 2-3 soft stools/day", sideEffects: "Flatulence, cramping initially", requiresPrescription: false },

  // More Respiratory (5)
  { name: "Montelukast 10mg", genericName: "Montelukast Sodium", category: "Respiratory Care", price: 65, mrp: 85, discount: 24, manufacturer: "MSD", description: "Leukotriene receptor antagonist for asthma and allergic rhinitis", dosage: "1 tablet once daily in the evening", sideEffects: "Headache, GI discomfort, mood changes", requiresPrescription: true },
  { name: "Fluticasone Nasal Spray", genericName: "Fluticasone Propionate", category: "Respiratory Care", price: 185, mrp: 242, discount: 24, manufacturer: "GSK", description: "Nasal corticosteroid for allergic rhinitis", dosage: "2 sprays in each nostril once daily", sideEffects: "Nasal dryness, headache, epistaxis", requiresPrescription: false },
  { name: "Ipratropium Inhaler", genericName: "Ipratropium Bromide", category: "Respiratory Care", price: 145, mrp: 190, discount: 24, manufacturer: "Boehringer", description: "Anticholinergic bronchodilator for COPD", dosage: "2 puffs 3-4 times daily", sideEffects: "Dry mouth, urinary retention, blurred vision", requiresPrescription: true },
  { name: "Doxofylline 400mg", genericName: "Doxofylline", category: "Respiratory Care", price: 68, mrp: 88, discount: 23, manufacturer: "Cipla", description: "Bronchodilator for asthma with fewer side effects than theophylline", dosage: "1 tablet twice daily", sideEffects: "Nausea, palpitations, headache", requiresPrescription: true },
  { name: "N-Acetylcysteine 600mg", genericName: "N-Acetylcysteine", category: "Respiratory Care", price: 52, mrp: 68, discount: 24, manufacturer: "Sun Pharma", description: "Mucolytic agent for respiratory conditions and antioxidant", dosage: "1 sachet dissolved in water twice daily", sideEffects: "Nausea, rash, bronchoconstriction", requiresPrescription: false },

  // Eye Care (5)
  { name: "Lubricant Eye Gel", genericName: "Carbomer 0.2%", category: "Eye Care", price: 125, mrp: 165, discount: 24, manufacturer: "Alcon", description: "Night-time gel for severe dry eye syndrome", dosage: "Apply 1 ribbon to lower eyelid at bedtime", sideEffects: "Temporary blurring of vision", requiresPrescription: false },
  { name: "Brimonidine 0.2% Drops", genericName: "Brimonidine Tartrate", category: "Eye Care", price: 195, mrp: 256, discount: 24, manufacturer: "Allergan", description: "Alpha-2 agonist for lowering intraocular pressure in glaucoma", dosage: "1 drop in affected eye twice daily", sideEffects: "Eye redness, dry mouth, drowsiness", requiresPrescription: true },
  { name: "Ciprofloxacin Eye Drops 0.3%", genericName: "Ciprofloxacin HCl", category: "Eye Care", price: 48, mrp: 62, discount: 23, manufacturer: "Alcon", description: "Antibiotic eye drops for bacterial conjunctivitis", dosage: "1-2 drops 4-6 times daily for 7 days", sideEffects: "Temporary stinging, eye irritation", requiresPrescription: true },
  { name: "Nepafenac 0.1% Eye Drops", genericName: "Nepafenac", category: "Eye Care", price: 185, mrp: 242, discount: 24, manufacturer: "Alcon", description: "NSAID eye drop for ocular pain and inflammation post-surgery", dosage: "1 drop 3 times daily starting 1 day before surgery", sideEffects: "Stinging, burning, foreign body sensation", requiresPrescription: true },
  { name: "Tropicamide 1% Drops", genericName: "Tropicamide", category: "Eye Care", price: 42, mrp: 55, discount: 24, manufacturer: "Sun Pharma", description: "Short-acting mydriatic for eye examination and uveitis", dosage: "1-2 drops before eye examination", sideEffects: "Blurred vision, photophobia, increased IOP", requiresPrescription: true },
];

async function seedMoreMedicines() {
  console.log(`Seeding ${moreMedicines.length} additional medicines...`);
  
  const toInsert = moreMedicines.map((m) => ({
    name: m.name,
    genericName: m.genericName || null,
    category: m.category,
    price: m.price.toString(),
    mrp: m.mrp.toString(),
    discount: m.discount,
    manufacturer: m.manufacturer,
    description: m.description,
    dosage: m.dosage || null,
    sideEffects: m.sideEffects || null,
    requiresPrescription: m.requiresPrescription ?? false,
    inStock: m.inStock ?? true,
    imageUrl: null,
  }));

  await db.insert(medicinesTable).values(toInsert);
  console.log(`✅ Successfully seeded ${toInsert.length} additional medicines!`);
  
  const { sql } = await import("drizzle-orm");
  const result = await db.execute(sql`SELECT COUNT(*) as count FROM medicines`);
  console.log(`📊 Total medicines in database: ${result.rows[0].count}`);
}

seedMoreMedicines()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Seeding failed:", err);
    process.exit(1);
  });
